package com.laoxu.java.authman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthmanApplicationTests {

    @Test
    void contextLoads() {
    }

}
