package com.laoxu.java.authman.common;

import lombok.Data;

/**
 * @Description: 下拉实体模型
 * @Author laoxu
 * @Date 2021/4/7 9:58
 **/
@Data
public class SelectEntity {
    private Integer id;
    private String name;
}
