package com.laoxu.java.authman.vo;

/**
 * @Description: 加载权限树用的
 * @Author laoxu
 * @Date 2021/4/6 14:23
 **/
public class MenuTreeVO {
}
