package com.laoxu.java.authman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthmanApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuthmanApplication.class, args);
    }

}
